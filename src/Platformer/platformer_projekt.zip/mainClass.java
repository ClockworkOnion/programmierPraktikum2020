public class mainClass {
    public static void main(String[] args) {

    MyGraphics testGraphics = new MyGraphics();
    testGraphics.DrawImg();

    }
}
