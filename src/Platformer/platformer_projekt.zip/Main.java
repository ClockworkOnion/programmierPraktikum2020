
public class Main {

	public static void main(final String[] args) {
		// TODO Auto-generated method stub
		// new Platformer();
		new Platformer();
	}

}
 